/**
 * Variable03.java
 *
 * Copyright (C) 2014 by Future Architect, Inc. Japan
 */

package drill.step01;

/**
 * 指定された標準出力を行えるように実装しなさい
 * [キーワード]java 変数 代入
 *
 * @author mano
 *
 */
public class Variable03 {

	public static void main(String[] args) {

		// TODO 1: 次の変数aとbの値を一次変数tmpを用いて入れ替えなさい
		int a = 1980;
		int b = 1680;
		int tmp;
		//-----↓実装ここから↓-------
		tmp = a;
		a = b;
		b = tmp;
		//-----↑実装ここまで↑-------
		// =======================================================
		// [出力結果]
		// =======================================================
		// 実行してa=1680,b=1980と出力されれば正解です。
		System.out.println("a=" + a + ",b=" + b);
	}

}
