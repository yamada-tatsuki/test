package app;

import java.io.Serializable;

/**
 * 趣味情報を保持するクラス
 *
 * @author mano
 *
 */
public class Hobby implements Serializable {

	public Hobby() {
		// 何もしない
	}

	/** 趣味 */
	private String hobby;

	/** 趣味カテゴリ */
	private String hobbyCategory;

	/** No */
	private String no;

	/** 社員名 */
	private String syainName;

	public String getHobby() {
		return hobby;
	}


	public void setHobby(String hobby) {
		this.hobby = hobby;
	}


	public String getHobbyCategory() {
		return hobbyCategory;
	}


	public void setHobbyCategory(String hobbyCategory) {
		this.hobbyCategory = hobbyCategory;
	}


	public void setNo(String no) {
		this.no = no;
	}


	public String getNo() {
		return no;
	}

	public void setSyainName(String syainName) {
		this.syainName = syainName;
	}


	public String getSyainName() {
		return syainName;
	}


	@Override
	public String toString() {
		return "Hobby [hobby=" + hobby + ", hobbyCategory=" + hobbyCategory + ", no=" + no + ", syainName=" + syainName +"]";
	}

}
