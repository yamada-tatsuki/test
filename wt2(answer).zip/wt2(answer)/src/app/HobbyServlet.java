package app;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet("/api/hobby")
public class HobbyServlet extends HttpServlet {

	/********************************************************************************
	 * 以下のdoGet/doPostを実装して下さい。
	 * importなどは自由に行って下さい。
	 ********************************************************************************/

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		// TODO 必須機能「趣味参照機能」

		String syainId = request.getParameter("syainId");

		try (
				// データベースへ接続します
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "wt2", "wt2");

				// SQLの命令文を実行するための準備をおこないます
				Statement stmt = con.createStatement();

				// SQLの命令文を実行し、その結果をResultSet型のrsに代入します
				ResultSet rs = stmt.executeQuery(
								"select \n" +
								"	rownum as NO \n" +
								",	res.SYAINID \n" +
								",	res.SYAINNAME \n" +
								",	res.CATEGORY_ID \n" +
								",	res.CATEGORY_NAME \n" +
								",	res.HOBBY_ID \n" +
								",	res.HOBBY_NAME \n" +
								"from( \n" +
								"	select \n" +
								"		msh.SYAINID			as SYAINID \n" +
								"	,	ms.SYAINNAME		as SYAINNAME \n" +
								"	,	mh.CATEGORY_ID		as CATEGORY_ID \n" +
								"	,	mc.CATEGORY_NAME	as CATEGORY_NAME \n" +
								"	,	msh.HOBBY_ID		as HOBBY_ID \n" +
								"	,	mh.HOBBY_NAME		as HOBBY_NAME \n" +
								"	from \n" +
								"		MS_SYAIN_HOBBY	msh \n" +
								"	,	MS_SYAIN		ms \n" +
								"	,	MS_HOBBY		mh \n" +
								"	,	MS_CATEGORY		mc \n" +
								"	where 1=1 \n" +
								"	and msh.SYAINID = '" + syainId +"' \n" +
								"	and msh.SYAINID = ms.SYAINID \n" +
								"	and msh.HOBBY_ID = mh.HOBBY_ID \n" +
								"	and mh.CATEGORY_ID = mc.CATEGORY_ID \n" +
								"	order by msh.SYAINID, mc.CATEGORY_ID, msh.HOBBY_ID \n" +
								")res");

		){
			List<Hobby> list = new ArrayList<>();

			while (rs.next()) {
				Hobby hobby = new Hobby();

				hobby.setNo(rs.getString("NO"));
				hobby.setHobbyCategory(rs.getString("CATEGORY_NAME"));
				hobby.setHobby(rs.getString("HOBBY_NAME"));
				hobby.setSyainName(rs.getString("SYAINNAME"));

				list.add(hobby);
			}

			PrintWriter w = response.getWriter();
			w.write(new ObjectMapper().writeValueAsString(list));

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		// -- ここまで --
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		// TODO 任意機能「趣味投稿機能に挑戦する場合はこちらを利用して下さい」

		// -- ここまで --
	}

}
